//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SetupDll.rc
//
#define IDS_DeleteSavedData             101
#define IDS_AddtoHomeScreen             102
#define IDR_MENU                        102
#define IDS_Disclaimer                  103
#define IDS_DisclaimerMsg               104
#define IDD_DLG_Basic                   105
#define IDR_MENU_InstallCancel          106
#define IDR_CEUX1                       107
#define IDR_MENU_OkCancel               108
#define IDS_MSG_Notepad                 110
#define IDS_MSG_Contacts                110
#define IDS_MSG_DeleteSettings          111
#define IDS_MENU_Ok                     119
#define IDS_MENU_Accept                 120
#define IDS_STRING121                   121
#define IDS_MENU_Deny                   121
#define IDS_MENU_Install                122
#define IDS_MENU_Cancel                 123
#define IDS_CMPT_Install                124
#define IDS_CMPT_Battery                125
#define IDS_CMPT_Explorer               126
#define IDS_CMPT_Regedit                127
#define IDS_CMPT_Notepad                128
#define IDS_CMPT_Taskman                129
#define IDS_CMPT_SciCalc                130
#define IDS_CMPT_FreeCell               131
#define IDS_STRING132                   132
#define IDS_CMPT_MineSweeper            132
#define IDS_CMPT_Tasks                  133
#define ID_ACCEPT                       40001
#define IDMENU_Accept                   40002
#define ID_DENY                         40003
#define IDMENU_Deny                     40004
#define ID_INSTALL                      40005
#define IDMENU_Install                  40006
#define ID_CANCEL                       40007
#define IDMENU_Cancel                   40008
#define ID_OK                           40009
#define IDMENU_Ok                       40010
#define ID_CANCEL40011                  40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
